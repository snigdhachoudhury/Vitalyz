
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import DataFlow from './components/DataFlow';
import Testimonials from './components/Testimonials';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="bg-gradient-to-b from-[#082F2C] to-[#0D4742] min-h-screen font-sans text-white antialiased">
      <Header />
      <main>
        <Hero />
        <DataFlow />
        <Features />
        <Testimonials />
      </main>
      <Footer />
    </div>
  );
};

export default App;