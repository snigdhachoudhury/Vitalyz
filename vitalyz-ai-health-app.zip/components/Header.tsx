
import React from 'react';
import LogoIcon from './icons/LogoIcon';

const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 bg-[#082F2C]/80 backdrop-blur-lg">
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <LogoIcon className="w-8 h-8 text-[#00FFFF]" />
          <h1 className="text-2xl font-bold text-white tracking-tight">Vitalyz</h1>
        </div>
        <a
          href="#download"
          className="hidden sm:inline-block bg-[#00FFFF] text-[#0D4742] font-bold px-6 py-2 rounded-full hover:bg-white transition-all duration-300 transform hover:scale-105 shadow-[0_0_15px_#00FFFF55] hover:shadow-[0_0_25px_#00FFFF88]"
        >
          Download Now
        </a>
      </div>
       <div className="w-full h-px bg-white/10"></div>
    </header>
  );
};

export default Header;
