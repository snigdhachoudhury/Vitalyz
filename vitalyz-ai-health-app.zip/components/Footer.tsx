
import React from 'react';
import LogoIcon from './icons/LogoIcon';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#082F2C] border-t border-white/10">
      <div className="container mx-auto px-6 py-8 flex flex-col items-center gap-4 text-center text-white/60">
        <div className="flex items-center space-x-3">
          <LogoIcon className="w-7 h-7" />
          <span className="text-xl font-semibold text-white/80">Vitalyz</span>
        </div>
        <p>&copy; {new Date().getFullYear()} Vitalyz Inc. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
