import React from 'react';

const AnimatedArrowIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    width="64"
    height="64"
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <style>{`
      .flow-arrow {
        stroke-dasharray: 10 10;
        animation: flow 2s linear infinite;
      }

      @keyframes flow {
        from {
          stroke-dashoffset: 20;
        }
        to {
          stroke-dashoffset: 0;
        }
      }
    `}</style>
    
    {/* Faint static background arrow */}
    <path
      d="M12 32 H52 M44 24 L52 32 L44 40"
      stroke="#22D3EE"
      strokeWidth="2"
      strokeOpacity="0.3"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />

    {/* Animated flow arrow */}
    <path
      className="flow-arrow"
      d="M12 32 H52 M44 24 L52 32 L44 40"
      stroke="#22D3EE"
      strokeWidth="4"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
  </svg>
);

export default AnimatedArrowIcon;