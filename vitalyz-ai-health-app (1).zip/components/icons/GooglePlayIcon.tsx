
import React from 'react';

const GooglePlayIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="currentColor"
    stroke="currentColor"
    strokeWidth="0"
    {...props}
  >
    <path d="M3 7l10-6 10 6-10 6-10-6z" />
    <path d="M3 17l10 6 10-6" />
    <path d="M3 12l10-6 10 6" />
  </svg>
);

export default GooglePlayIcon;
