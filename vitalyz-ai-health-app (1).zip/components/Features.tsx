import React from 'react';
import SunIcon from './icons/SunIcon';
import WaterDropIcon from './icons/WaterDropIcon';
import HeartPulseIcon from './icons/HeartPulseIcon';

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description }) => {
  return (
    <div className="bg-gradient-to-br from-white/5 to-transparent p-8 rounded-2xl border border-white/20 hover:border-[#22D3EE] hover:bg-white/10 transition-all duration-300 transform hover:-translate-y-2 group">
      <div className="mb-6 w-16 h-16 rounded-xl bg-white/10 flex items-center justify-center text-[#22D3EE] transition-all duration-300 group-hover:bg-[#22D3EE] group-hover:text-[#05141F] group-hover:scale-110 group-hover:rotate-12">
        {icon}
      </div>
      <h3 className="text-xl font-bold text-white">{title}</h3>
      <p className="mt-2 text-white/70">{description}</p>
    </div>
  );
};

const Features: React.FC = () => {
  return (
    <section className="py-32 bg-[#05141F]">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold tracking-tight">Predictive Health Insights</h2>
          <p className="mt-4 text-lg text-white/70">
            Our AI models analyze your biometric data to provide early warnings for potential health issues, empowering you to take preventive action.
          </p>
        </div>
        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <FeatureCard
            icon={<SunIcon className="w-10 h-10" />}
            title="Heatstroke Prediction"
            description="Stay ahead of heat-related illness with real-time risk assessment based on your body temperature, activity, and environmental data."
          />
          <FeatureCard
            icon={<WaterDropIcon className="w-10 h-10" />}
            title="Dehydration Alerts"
            description="Receive smart reminders to hydrate based on your personal needs, activity levels, and sweat rate analysis."
          />
          <FeatureCard
            icon={<HeartPulseIcon className="w-10 h-10" />}
            title="Organ Stress Risk"
            description="Monitor vital signs for patterns indicating potential strain on your heart, kidneys, and other critical organs."
          />
        </div>
      </div>
    </section>
  );
};

export default Features;