import React from 'react';
import LogoIcon from './icons/LogoIcon';

const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 bg-[#05141F]/80 backdrop-blur-lg">
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <LogoIcon className="w-8 h-8 text-[#22D3EE]" />
          <h1 className="text-2xl font-bold text-white tracking-tight">Vitalyz</h1>
        </div>
        <a
          href="#download"
          className="hidden sm:inline-block bg-gradient-to-r from-[#22D3EE] to-[#00FFC4] text-black font-bold px-6 py-2 rounded-full hover:opacity-90 transition-all duration-300 transform hover:scale-105 shadow-[0_0_20px_#22D3EE55] hover:shadow-[0_0_30px_#22D3EE88]"
        >
          Download Now
        </a>
      </div>
       <div className="w-full h-px bg-white/10"></div>
    </header>
  );
};

export default Header;