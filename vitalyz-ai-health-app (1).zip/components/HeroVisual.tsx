import React from 'react';

const HeroVisual: React.FC = () => {
  const bars = [
    { height: '30%', delay: '0s' },
    { height: '50%', delay: '0.2s' },
    { height: '20%', delay: '0.4s' },
    { height: '70%', delay: '0.6s' },
    { height: '40%', delay: '0.8s' },
    { height: '60%', delay: '1s' },
    { height: '35%', delay: '1.2s' },
    { height: '55%', delay: '1.4s' },
    { height: '25%', delay: '1.6s' },
    { height: '75%', delay: '1.8s' },
    { height: '45%', delay: '2s' },
    { height: '65%', delay: '2.2s' },
    { height: '30%', delay: '2.4s' },
    { height: '50%', delay: '2.6s' },
    { height: '20%', delay: '2.8s' },
  ];

  return (
    <>
      <style>{`
        @keyframes pulse-bar {
          0%, 100% { transform: scaleY(0.5); opacity: 0.5; }
          50% { transform: scaleY(1); opacity: 1; }
        }
        .animate-pulse-bar {
          animation: pulse-bar 4s ease-in-out infinite;
          transform-origin: bottom;
        }
        @keyframes shimmer {
          0% { transform: translateX(-100%) skewX(-20deg); }
          100% { transform: translateX(200%) skewX(-20deg); }
        }
        .shimmer-line {
          position: absolute;
          top: 0;
          left: 0;
          width: 50%;
          height: 100%;
          background: linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.1) 50%, rgba(255,255,255,0) 100%);
          animation: shimmer 3s ease-in-out infinite;
          animation-delay: 1s;
        }
      `}</style>
      <div className="max-w-4xl mx-auto bg-black/20 p-2 rounded-2xl shadow-2xl shadow-[#22D3EE]/20 ring-1 ring-white/20">
        <div className="relative aspect-video sm:aspect-[4/3] rounded-xl bg-gradient-to-br from-[#05141F] via-[#0B383E] to-[#05141F] overflow-hidden p-8 flex items-end justify-between">
          {/* Animated Bars */}
          {bars.map((bar, index) => (
            <div key={index} className="w-4 rounded-full bg-gradient-to-b from-[#22D3EE] to-[#00FFC4] animate-pulse-bar" style={{ height: bar.height, animationDelay: bar.delay }}></div>
          ))}

          {/* Shimmer Effect */}
          <div className="shimmer-line"></div>
        </div>
      </div>
    </>
  );
};

export default HeroVisual;
