import React from 'react';
import WatchIcon from './icons/WatchIcon';
import AnimatedArrowIcon from './icons/AnimatedArrowIcon';
import PhoneIcon from './icons/PhoneIcon';

const DataFlow: React.FC = () => {
  return (
    <section className="py-24">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl font-bold tracking-tight">Seamless Integration</h2>
        <p className="mt-4 text-lg text-white/70 max-w-2xl mx-auto">
          Vitalyz syncs effortlessly with your favorite wearables to analyze your vitals in real-time.
        </p>
        <div className="mt-16 flex flex-col md:flex-row items-center justify-center gap-8 md:gap-16">
          <div className="flex flex-col items-center gap-4">
            <div className="w-24 h-24 bg-white/5 border border-white/10 rounded-full flex items-center justify-center animate-pulse-glow">
              <WatchIcon className="w-12 h-12 text-[#22D3EE]" />
            </div>
            <span className="text-lg font-semibold">Your Wearable</span>
          </div>
          <AnimatedArrowIcon className="w-16 h-16 text-white/50 transform md:-translate-y-5 rotate-90 md:rotate-0" />
          <div className="flex flex-col items-center gap-4">
             <div className="w-24 h-24 bg-white/5 border border-white/10 rounded-full flex items-center justify-center animate-pulse-glow animate-delay-1200">
              <PhoneIcon className="w-12 h-12 text-[#22D3EE]" />
            </div>
            <span className="text-lg font-semibold">Vitalyz App</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DataFlow;