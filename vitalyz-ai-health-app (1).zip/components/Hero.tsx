import React from 'react';
import AppleIcon from './icons/AppleIcon';
import GooglePlayIcon from './icons/GooglePlayIcon';
import HeroVisual from './HeroVisual';

const Hero: React.FC = () => {
  return (
    <section id="download" className="py-20 sm:py-32">
      <div className="container mx-auto px-6 text-center">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-extrabold text-white leading-tight tracking-tight">
            Vitalyz: Your Personalized
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-[#22D3EE] to-[#00FFC4] mt-2">
              AI Health Guardian
            </span>
          </h1>
          <p className="mt-6 text-lg md:text-xl text-white/80 max-w-2xl mx-auto">
            Leverage cutting-edge AI to predict and prevent health risks like heatstroke, dehydration, and organ stress before they happen. Your proactive wellness journey starts here.
          </p>
          <div className="mt-12 flex flex-col sm:flex-row justify-center items-center gap-4">
            <a href="#" className="flex items-center justify-center gap-3 w-full sm:w-auto bg-white text-black font-semibold px-8 py-3 rounded-full hover:bg-gray-200 transition-all duration-300 transform hover:scale-105">
              <AppleIcon className="w-6 h-6" />
              <span>App Store</span>
            </a>
            <a href="#" className="flex items-center justify-center gap-3 w-full sm:w-auto bg-transparent border-2 border-[#22D3EE] text-white font-semibold px-8 py-3 rounded-full hover:bg-[#22D3EE] hover:text-black transition-colors duration-300 transform hover:scale-105">
              <GooglePlayIcon className="w-6 h-6" />
              <span>Google Play</span>
            </a>
          </div>
        </div>
        <div className="mt-20 relative">
           <HeroVisual />
        </div>
      </div>
    </section>
  );
};

export default Hero;