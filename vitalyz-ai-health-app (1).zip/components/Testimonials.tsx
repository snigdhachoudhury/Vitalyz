import React from 'react';

const testimonialsData = [
  {
    quote: "Vitalyz is a game-changer. The heatstroke prediction saved me during my last marathon training session. I can't imagine my runs without it now.",
    name: 'Elena Rodriguez',
    role: 'Marathon Runner',
    avatar: 'https://images.pexels.com/photos/3775131/pexels-photo-3775131.jpeg?auto=compress&cs=tinysrgb&w=200',
  },
  {
    quote: "As a busy professional, I often forget to drink enough water. The dehydration alerts are subtle but incredibly effective. I feel more energetic throughout the day.",
    name: 'David Chen',
    role: 'Software Engineer',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=200',
  },
  {
    quote: "Keeping track of my heart health is my top priority. The organ stress risk monitor gives me and my family peace of mind. The interface is so simple to understand.",
    name: 'Sarah Jenkins',
    role: 'Retired Teacher',
    avatar: 'https://images.pexels.com/photos/762020/pexels-photo-762020.jpeg?auto=compress&cs=tinysrgb&w=200',
  },
];

const Testimonials: React.FC = () => {
  return (
    <section className="py-24 sm:py-32">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold tracking-tight">Loved by Users Worldwide</h2>
          <p className="mt-4 text-lg text-white/70">
            Don't just take our word for it. Hear from the people who trust Vitalyz to be their health guardian every day.
          </p>
        </div>
        <div className="mt-20 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonialsData.map((testimonial, index) => (
            <div 
              key={index} 
              className="bg-gradient-to-br from-white/5 to-transparent p-8 rounded-2xl border border-white/20 hover:border-[#22D3EE] transition-all duration-300 transform hover:-translate-y-2 flex flex-col"
            >
              <p className="text-white/80 flex-grow italic">"{testimonial.quote}"</p>
              <div className="mt-6 flex items-center gap-4 pt-6 border-t border-white/10">
                <img 
                  src={testimonial.avatar} 
                  alt={testimonial.name} 
                  className="w-14 h-14 rounded-full object-cover ring-2 ring-white/20" 
                />
                <div>
                  <p className="font-bold text-white">{testimonial.name}</p>
                  <p className="text-sm text-[#22D3EE]/80">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;